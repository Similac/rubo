#!/usr/bin/sh
#MR
hadoop="hadoop"
pwd=`echo $PWD | awk -F '/' '{print $NF}'`
EXTIONID=`echo -n ${pwd}`
jar_path="./uuid.channel.subid.ip.count.jar"
HDFS_OUT_PATH="s3://mob-export-log-support/test/log/${EXTIONID}/"
SOURCE="install"
UUIDS="nx_miniclip_8ball_uk_android_non_9172"
CHANNELS="null"
CLICKIDS="null"
IDFAS="null"
STARTDATE="2018-02-28-10"
ENDDATE="2018-02-28-11"
hadoop jar  uuid.channel.subid.ip.count.jar ${HDFS_OUT_PATH} ${SOURCE} ${UUIDS} ${CHANNELS} ${CLICKIDS} ${IDFAS} ${STARTDATE} ${ENDDATE}

echo "DONE"