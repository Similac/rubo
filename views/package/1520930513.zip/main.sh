#!/usr/bin/sh
#MR
hadoop="hadoop"
EXTIONID=`printf $PWD | awk -F '/' '{printf $NF}'`
jar_path="./uuid.channel.subid.ip.count.jar"
HDFS_OUT_PATH="s3://mob-export-log-support/test/log/${EXTIONID}/"
SOURCE="install"
UUIDS="int_hod_ca"
CHANNELS="null"
CLICKIDS="null"
IDFAS="null"
STARTDATE="2016-08-29-00"
ENDDATE="2016-08-29-23"
hadoop jar  uuid.channel.subid.ip.count.jar ${HDFS_OUT_PATH} ${SOURCE} ${UUIDS} ${CHANNELS} ${CLICKIDS} ${IDFAS} ${STARTDATE} ${ENDDATE}

echo "DONE"