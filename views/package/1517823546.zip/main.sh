#!/usr/bin/sh
#MR
HDFS_JSON="s3://mob-emr-test/rubo/dddd"
SOURCE="install"
STARTDATE="2018-02-01-01"
ENDDATE="2018-02-01-02"
UUIDS="douyin4_cn_ios"
CHANNELS="null"
CLICKIDS="null"
IDFAS="null"
EXPORTTYPE="json"
STARTDATE="2018-02-01-01"
ENDDATE="2018-02-01-02"
hadoop jar  uuid.channel.subid.ip.count.jar ${HDFS_JSON} ${SOURCE} ${UUIDS} ${CHANNELS} ${CLICKIDS} ${IDFAS} ${STARTDATE} ${ENDDATE} ${EXPORTTYPE}
echo "INSTALL DONE"