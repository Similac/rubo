#!/usr/bin/sh
#MR
HDFS_JSON="s3://mob-emr-test/rubo/ddd"
SOURCE="install"
STARTDATE="2018-01-31-17"
ENDDATE="2018-01-31-18"
UUIDS="rolling_sky3_cn_ios"
CHANNELS="null"
CLICKIDS="null"
IDFAS="null"
EXPORTTYPE="json"
STARTDATE="2018-01-31-17"
ENDDATE="2018-01-31-18"
hadoop jar  uuid.channel.subid.ip.count.jar ${HDFS_JSON} ${SOURCE} ${UUIDS} ${CHANNELS} ${CLICKIDS} ${IDFAS} ${STARTDATE} ${ENDDATE} ${EXPORTTYPE}
echo "INSTALL DONE"