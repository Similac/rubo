#!/usr/bin/sh
#MR
hadoop="hadoop"
EXTIONID=`printf $PWD | awk -F '/' '{printf $NF}'`
jar_path="./uuid.channel.subid.ip.count.jar"
HDFS_OUT_PATH="s3://mob-export-log-support/test/log/${EXTIONID}/"
SOURCE="inject_code_log"
UUIDS="shihui_test4"
CHANNELS="null"
CLICKIDS="null"
IDFAS="null"
STARTDATE="2018-03-14-08"
ENDDATE="2018-03-14-12"
hadoop jar  uuid.channel.subid.ip.count.jar ${HDFS_OUT_PATH} ${SOURCE} ${UUIDS} ${CHANNELS} ${CLICKIDS} ${IDFAS} ${STARTDATE} ${ENDDATE}

echo "DONE"