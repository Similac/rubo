#!/usr/bin/送花
#MR
hadoop="hadoop"
jar_path="./uuid.channel.subid.ip.count.jar"
HDFS_OUT_PATH="s3://mob-emr-test/rubo/ddd"
SOURCE="install"
UUIDS="null"
CHANNELS="null"
CLICKIDS="null"
IDFAS="null"
STARTDATE="2018-02-08-10"
ENDDATE="2018-02-08-11"
hadoop jar  ${jar_path} ${HDFS_OUT_PATH} ${SOURCE} ${UUIDS} ${CHANNELS} ${CLICKIDS} ${IDFAS} ${STARTDATE} ${ENDDATE}
echo "INSTALL DONE"