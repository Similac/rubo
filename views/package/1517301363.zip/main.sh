#!/usr/bin/sh
#MR
HDFS_JSON="s3://mob-emr-test/rubo/maintest/"
SOURCE="click"
STARTDATE="2018-01-23-00"
ENDDATE="2018-01-29-23"
UUIDS="xcx_test"
CHANNELS="null"
CLICKIDS="null"
IDFAS="null"
EXPORTTYPE="json"
STARTDATE="2018-01-23-00"
ENDDATE="2018-01-29-23"
hadoop jar  uuid.channel.subid.ip.count.jar ${HDFS_JSON} ${SOURCE} ${UUIDS} ${CHANNELS} ${CLICKIDS} ${IDFAS} ${STARTDATE} ${ENDDATE} ${EXPORTTYPE}
echo "INSTALL DONE"