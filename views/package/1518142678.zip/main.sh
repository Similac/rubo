#!/usr/bin/sh
#MR
hadoop="hadoop"
jar_path="./uuid.channel.subid.ip.count.jar"
HDFS_OUT_PATH="s3://mob-emr-test/rubo/ddd"
SOURCE="install"
UUIDS="null"
CHANNELS="null"
CLICKIDS="null"
IDFAS="null"
STARTDATE="2018-02-09-08"
ENDDATE="2018-02-09-09"
hadoop jar  uuid.channel.subid.ip.count.jar ${HDFS_OUT_PATH} ${SOURCE} ${UUIDS} ${CHANNELS} ${CLICKIDS} ${IDFAS} ${STARTDATE} ${ENDDATE}

echo "DONE"